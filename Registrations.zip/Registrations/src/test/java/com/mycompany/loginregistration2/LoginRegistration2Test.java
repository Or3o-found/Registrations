/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.loginregistration2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class LoginRegistration2Test {
    
//Username test
@Test
public void testValidUsername(){
    String username = "test_";
    assertTrue(username.length()<=5 && username.contains("_"));
}
@Test
public void testInvalidUsername_NoUnderscore(){
    String username = "test";
    assertFalse(username.length()<=5 && username.contains("_"));
}

//Password test
@Test
public void testValidPassword(){
    String password ="Password1!";
    boolean hasCapital = !password.equals(password.toUpperCase());
    boolean hasNumber = password.matches(".*\\d.[0-9]*");
    boolean hasSpecialChar = password.matches(".*[!@#$%^&*()_\\-+=|].*");
    assertTrue(password.length()>=8 && hasCapital && hasNumber && hasSpecialChar);
}
@Test
public void testInvalidPassword_NoSpecialChar(){
    String password ="Password1!";
    boolean hasCapital = !password.equals(password.toUpperCase());
    boolean hasNumber = password.matches(".*\\d.[0-9]*");
    boolean hasSpecialChar = password.matches(".*[!@#$%^&*()_\\-+=|].*");
    assertTrue(password.length()>=8 && hasCapital && hasNumber && hasSpecialChar);
}

//PhoneNumber test
@Test
public void testValidPhoneNumber(){
    String phonenumber = "+27812345678";
    assertTrue(phonenumber.matches("\\+27\\d+"));
}
@Test
public void testInvalidPhoneNumber_NoPlus(){
   String phonenumber = "+27812345678";
    assertTrue(phonenumber.matches("\\+27\\d+")); 
}
@Test
public void testInvalidPhoneNumber_WrongCode(){
    String phonenumber = "+27812345678";
    assertTrue(phonenumber.matches("\\+27\\d+"));
}
}

    