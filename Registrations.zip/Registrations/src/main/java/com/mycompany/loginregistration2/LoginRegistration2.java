/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loginregistration2;

import java.util.Scanner;

/**
 *
 * @author Student
 */
import java.util.Scanner;

public class LoginRegistration2 {

    public static void main(String[] args) {
      Scanner input = new Scanner(System.in);
              
/*User login with their username that must contain 5 characters and must contain _*/
    System.out.print("Enter username (<=5 characters and must contain_):");
    String username = input.nextLine();
    
//Validate username
    if(username.length() <=5 && username.contains("_")){
        System.out.println("Username successfully captured");
    } else {
        System.out.println("Username not correctly formatted: Must contain <=5 characters AND contain '_' ");
    }
    
/*User's password must contain least than 8 characters, a capital letter, a number and a special character*/
    System.out.print("Enter password(>=8 characters and must contain a capital letter, a number and a special character):");
    String password = input.nextLine();
              
//Validate password
    boolean hasCapital = !
       password.equals(password.toUpperCase());
    boolean hasNumber = password.matches(".\\d.[0-9]");
    boolean hasSpecialChar = password.matches("[!@#$%^&*()_\\-+=|].*");
      if(password.length() >=8 && hasCapital && hasNumber && hasSpecialChar){
       System.out.println("Password successfully captured");
    } else {
        System.out.println("Password is not correctly formatted: Must contain >=8 characters AND contain a capital letter, a number and a special character");
            }
//User enters their number
    System.out.print("Enter phonenumber(must start with +27): ");
    String phonenumber = input.nextLine();
    
//Validate phone number
    if(phonenumber.matches("\\+27\\d+")){
        System.out.println("phonenumber successfully captured");
    } else {
        System.out.println("phonenumber is not correctly formatted: Must contain the international code '+27' follwed by digits");
    }
   
//Ask user to login their details 
    System.out.print("\n---Login---");

    System.out.print("Enter your username:");
    String loginUsername = input.nextLine();
    
    System.out.print("Enetr your password:");
    String loginPassword = input.nextLine();
    
    System.out.print("Enter your phonenumber:");
    String loginPhonenumber = input.nextLine();
    
//Check if login matches the stored details 
    if(loginUsername.equalsIgnoreCase(username)&& loginPassword.equals(password)&& loginPhonenumber(phonenumber)){
        System.out.println("Login successful, Welcome!");
    } else {
        System.out.println("Login Failed, Please try again.");
    }
    } 

    private static boolean loginPhonenumber(String phonenumber) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    }

